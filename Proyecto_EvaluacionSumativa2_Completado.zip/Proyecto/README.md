# Portal Web Modular: Noticias y Cine

Proyecto de **Programación Back End (TI3041), Evaluación Sumativa 2**. Continúa el sitio modular anterior y conserva las aplicaciones `noticias` y `cine`. Los datos que muestran las páginas se leen desde una base de datos relacional mediante Django ORM.

## Descripción y funcionalidades

- **Noticias:** categorías y noticias con fecha, resumen, contenido, destacado e imagen.
- **Cine:** géneros y películas con director, año, calificación, sinopsis, estreno e imagen.
- Listados, fichas y búsqueda por título para ambos módulos.
- Panel Django Admin con alta, consulta, edición, eliminación, filtros y búsqueda para las cuatro entidades. Los formularios relacionados enlazan a sus categorías o géneros.
- Los botones Agregar, Modificar y Eliminar del sitio son marcadores visuales para la evaluación siguiente; las operaciones CRUD funcionales se realizan desde `/admin/`, como indica esta pauta.
- Los comandos `cargar_noticias` y `cargar_peliculas` importan los JSON heredados a la BD. Las vistas no leen JSON.

## Arquitectura y modelo

`mi_proyecto` contiene configuración y rutas; `noticias` y `cine` son aplicaciones Django separadas; `templates/base.html` y `static/` comparten interfaz Bootstrap local. Cada aplicación incluye modelos, vistas, URLs, admin, migración inicial y comando para importar los datos originales.

| Tabla/modelo | Relación | Propósito |
|---|---|---|
| `noticias_categoria` (`Categoria`) | 1:N con `Noticia` | Clasificación temática |
| `noticias_noticia` (`Noticia`) | FK a `Categoria` | Publicaciones del portal |
| `cine_genero` (`Genero`) | 1:N con `Pelicula` | Clasificación cinematográfica |
| `cine_pelicula` (`Pelicula`) | FK a `Genero` | Cartelera de películas |

Las migraciones `noticias/migrations/0001_initial.py` y `cine/migrations/0001_initial.py` crean esas tablas y llaves foráneas. Django también crea las tablas internas de autenticación, sesiones y administración.

## Requisitos y ejecución local

Requiere Python compatible con Django 6.1 y pip. En Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
Copy-Item .env.example .env
```

Edita `.env`: establece una clave aleatoria en `SECRET_KEY`; deja `DB_ENGINE=sqlite3` para iniciar localmente. Luego:

```powershell
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py cargar_noticias
python manage.py cargar_peliculas
python manage.py createsuperuser
python manage.py runserver
```

Abre `http://127.0.0.1:8000/`, `/noticias/`, `/cine/` y `/admin/`. En Linux/macOS activa con `source .venv/bin/activate` y copia la plantilla con `cp .env.example .env`.

## Variables de entorno y base de datos

La configuración se carga con `python-decouple`. `.env` contiene secretos, está excluido por `.gitignore` y no se distribuye; `.env.example` es solo una plantilla. En SQLite basta `SECRET_KEY`, `DEBUG`, `ALLOWED_HOSTS` y `DB_ENGINE=sqlite3`. Para MySQL configura `DB_ENGINE=mysql`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST` y `DB_PORT` en el `.env` privado. No uses credenciales de ejemplo en una instancia real.

## Despliegue de referencia en AWS EC2 (Ubuntu + MySQL)

El código está preparado para MySQL, pero crear la instancia, configurar GitHub, credenciales, grupo de seguridad y phpMyAdmin requiere las cuentas del estudiante. Secuencia en una instancia propia:

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip git default-libmysqlclient-dev build-essential pkg-config mysql-server
# Crea la BD y un usuario MySQL local con contraseña segura.
git clone URL_DEL_REPOSITORIO
cd Proyecto
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

En `.env` define una `SECRET_KEY` nueva, `DEBUG=False`, `ALLOWED_HOSTS=IP_PUBLICA_EC2`, `DB_ENGINE=mysql` y las credenciales MySQL. Continúa:

```bash
python manage.py migrate
python manage.py cargar_noticias
python manage.py cargar_peliculas
python manage.py createsuperuser
python manage.py check --deploy
python manage.py collectstatic --noinput
python manage.py runserver 0.0.0.0:8000
```

Abre TCP/8000 solo para la IP de revisión (o configura Nginx/Gunicorn y HTTPS para operación pública). En phpMyAdmin se pueden comprobar tablas, relaciones y registros. La pauta requiere evidencia real de EC2, GitHub y phpMyAdmin: debe capturarse desde la instancia y cuentas configuradas; este paquete no incluye capturas inventadas.

## Git y evidencias

Publica en un repositorio propio; revisa que `.env` y `.venv/` no estén en `git status`, registra commits y configura `origin` con la URL real. La demostración solicitada en EC2 es clonar esa URL con `git clone URL_DEL_REPOSITORIO`.

Antes de la revisión, reúne capturas del repositorio e historial de commits; clonación y terminal EC2 con entorno activo y aplicación ejecutándose; modelos y migraciones aplicadas; tablas, relaciones y registros en phpMyAdmin; operaciones de alta, edición, búsqueda y eliminación en Django Admin; vistas públicas y controles de acción. La pauta también pide evidencia concreta del uso de IA.

## Uso de IA en esta continuación

Prompt utilizado: “Revisa la pauta de la Evaluación Sumativa 2 y el proyecto Django adjunto; identifica brechas y complétalo para cubrir persistencia relacional, Django ORM/Admin, variables de entorno, navegación, evidencia y despliegue documentado”.

Aplicación: se revisó la pauta y el código; se comprobó que existen dos aplicaciones, modelos relacionados, migraciones, registro CRUD en Django Admin, vistas ORM, búsqueda, botones visuales y carga inicial de JSON. Se excluyó del paquete el `.env` recibido para no redistribuir su clave. Se reforzó la validación de `SECRET_KEY` y `DB_ENGINE`, y se completó esta guía de instalación, arquitectura y despliegue. Respuesta resumida: conservar CRUD funcional en Django Admin, configurar secretos por `.env`, migrar y poblar tablas relacionales, y documentar por separado las pruebas presenciales de AWS/GitHub/phpMyAdmin.

## Lista de revisión presencial

- [ ] Crear y configurar instancia EC2 Linux, MySQL y acceso de red.
- [ ] Publicar en el repositorio GitHub personal y demostrar commits y clonación.
- [ ] Crear `.env` privado en EC2, ejecutar migraciones y cargar registros.
- [ ] Crear superusuario y demostrar CRUD/búsqueda desde Django Admin.
- [ ] Mostrar listados ORM y tablas/relaciones/registros en phpMyAdmin.
- [ ] Adjuntar capturas auténticas de AWS, GitHub, BD y evidencia de IA.
